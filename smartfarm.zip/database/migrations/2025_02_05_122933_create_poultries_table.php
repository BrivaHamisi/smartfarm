<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('poultry', function (Blueprint $table) {
            $table->id();
            $table->date('date');
            $table->integer('chicken_count');
            $table->integer('mortalities')->default(0);
            $table->integer('eggs_produced');
            $table->integer('eggs_sold');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('poultry');
    }
};
