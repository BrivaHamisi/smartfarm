<?php if (isset($component)) { $__componentOriginale62345a8f06a70a953cd8f0e62a5c2b1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale62345a8f06a70a953cd8f0e62a5c2b1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dlayout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Profile')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <?php echo $__env->make('profile.partials.update-profile-information-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>

            <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <?php echo $__env->make('profile.partials.update-password-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>

            <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <?php echo $__env->make('profile.partials.delete-user-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale62345a8f06a70a953cd8f0e62a5c2b1)): ?>
<?php $attributes = $__attributesOriginale62345a8f06a70a953cd8f0e62a5c2b1; ?>
<?php unset($__attributesOriginale62345a8f06a70a953cd8f0e62a5c2b1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale62345a8f06a70a953cd8f0e62a5c2b1)): ?>
<?php $component = $__componentOriginale62345a8f06a70a953cd8f0e62a5c2b1; ?>
<?php unset($__componentOriginale62345a8f06a70a953cd8f0e62a5c2b1); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Hp\Documents\Projects\Laravel\smartfarm\resources\views\profile\edit.blade.php ENDPATH**/ ?>